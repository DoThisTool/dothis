﻿You already have the offline copy. Open index.html in the parent folder.
